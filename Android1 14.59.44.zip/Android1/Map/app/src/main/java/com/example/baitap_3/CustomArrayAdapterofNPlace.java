//package com.example.baitap_3;
//
//import android.content.Context;
//import android.widget.ArrayAdapter;
//
//public class CustomArrayAdapterofNPlace extends ArrayAdapter<NamePlace> {
//    Context context;
//}
